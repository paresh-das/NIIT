class AccountHolder
{

	public static String Name;
	public  static String AccountNumber;
	public static  String AccountType;
	public static  String Balance;
        public static String userid;

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
        public String password;

	public AccountHolder()
	{
		Name="";
		AccountNumber="0";
		AccountType="Savings";
		
                
	}

	

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getAccountNumber() {
        return AccountNumber;
    }

    public void setAccountNumber() {
       String AccountNumber=String.valueOf(Math.random()*100000+3333300000L);
        this.AccountNumber = AccountNumber;
    }

    public String getAccountType() {
        return AccountType;
    }

    public void setAccountType(String AccountType) {
        this.AccountType = AccountType;
    }

    public String getBalance() {
        return Balance;
    }

    public void setBalance(String Balance) {
        this.Balance = Balance;
    }
    
    public boolean compareTo(String pass)
    {
        if(pass.equalsIgnoreCase(password))
        {
            return true;
        }
        return false;
    }
        
}

	

	