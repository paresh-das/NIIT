
public class BankTransaction {
    
  public static String  otheracc;
    public void withdraw_money(String money)
    {
        
        AccountHolder.Balance=String.valueOf(Integer.parseInt(AccountHolder.Balance)-Integer.parseInt(money));
    }
    
    public void deposite_money(String money)
    {
        
        AccountHolder.Balance=String.valueOf(Integer.parseInt(AccountHolder.Balance)+Integer.parseInt(money));
    }
    
    public void transfer_money(String money,String anotheracc)
    {
        AccountHolder ac=new AccountHolder();
        otheracc=anotheracc;
        AccountHolder.Balance=String.valueOf(Integer.parseInt(AccountHolder.Balance)-Integer.parseInt(money));
    }
}
    
    
    
    

