import java.util.*;
import java.util.Collections.*;
public class MainClass {
    
    public static void main(String [] args)
    {
            AccountHolder ac=new AccountHolder();
            BankTransaction bk=new BankTransaction();
            String d;
            Scanner sc=new Scanner(System.in);
            do
            {
            System.out.println("\t.......Welcome to Bank of Dausin:...........");
            System.out.println();
            System.out.println("\t--------------Main Menu-------------------");
            System.out.println("1.Open an Account");
            System.out.println("2. View Balance");
            System.out.println("3. Withdraw Money");
            System.out.println("4. Deposite Money");
            System.out.println("5. Transfer Money");
            System.out.println();
            System.out.println("Please Enter Your Opption..");
            
            
            String option=sc.next();
            switch(option)
            {
                case "1":
                    
                    System.out.println("Enter Name :");
                    String nm=sc.next();
                    System.out.println("Enter type :");
                    String type=sc.next();
                    System.out.println("Enter userId :");
                    String id=sc.next();
                    System.out.println("Enter password :");
                    String pass=sc.next();
                    System.out.println("Enter Deposite :");
                    String deposite=sc.next();
                    ac.setName(nm);
                    ac.setAccountType(type);
                    ac.setAccountNumber();
                    ac.setPassword(pass);
                    ac.setUserid(id);
                    ac.setBalance(deposite);
                    
                    break;
                case "2":
                     System.out.println("Your Id:--");
                     String idd=sc.next();
                     System.out.println("Your Password:--");
                     String passs=sc.next();
                     if(ac.compareTo(passs))
                     {
                    
                    System.out.println("Your Last Balance:--");
                    System.out.print("Amount:--");
                    System.out.print("\t"+ac.getBalance());
                    System.out.println();
                     }
                     else
                     {
                         System.out.println("Please Enter Correct Password");
                     }
                    break;
                 case "3":
                     System.out.println("Your Id:--");
                     String idd_1=sc.next();
                     System.out.println("Your Password:--");
                     String passs_1=sc.next();
                     
                      if(ac.compareTo(passs_1))
                     {
                     System.out.println("Please Enter the amount to Withdraw:--");
                     String m=sc.next();
                     bk.withdraw_money(m);
                     System.out.println("After Withdraw Money the Balance is:--");
                     System.out.print("Amount:--");
                     System.out.print("\t"+ac.getBalance());
                     System.out.println();
                     }
                      
                      else
                     {
                         System.out.println("Please Enter Correct Password");
                     }
                     
                     
                     
                    break;
                 case "4":
                     
                      System.out.println("Your Id:--");
                     String idd_2=sc.next();
                     System.out.println("Your Password:--");
                     String passs_2=sc.next();
                     
                      if(ac.compareTo(passs_2))
                     {
                     
                     System.out.println("Please Enter the amount to Deposite:--");
                     String dd=sc.next();
                     bk.deposite_money(dd);
                     System.out.println("After Deposite Money the Balance is:--");
                     System.out.print("Amount:--");
                     System.out.print("\t"+ac.getBalance());
                     System.out.println();
                     }
                      else
                      {
                           System.out.println("Please Enter Correct Password");
                      }
                    break;
                 case "5":
                     System.out.println("Your Id:--");
                     String idd_3=sc.next();
                     System.out.println("Your Password:--");
                     String passs_3=sc.next();
                     if(ac.compareTo(passs_3))
                     {
                     
                     System.out.println("Please Enter the name to Transfer:--");
                     String tn=sc.next();
                     System.out.println("Please Enter the amount to Transfer:--");
                     String tm=sc.next();
                     bk.transfer_money(tm,tn);
                     System.out.println("After Transfer Money the details is:--");
                     System.out.println();
                     System.out.print("Name to whome Tranfer:--");
                     System.out.print("\t"+BankTransaction.otheracc);
                     System.out.println();
                     System.out.print("Amount that Transfer:--");
                     System.out.print("\t"+"- "+tm);
                     System.out.println();
                     System.out.print("Amount:--");
                     System.out.print("\t"+ac.getBalance());
                     System.out.println();
                     }
                     else
                     {
                          System.out.println("Please Enter Correct Password");
                     }
                    break;
                
                default:
                    System.out.println("nvalid Option");
                    break;
            }
            System.out.println("do you want to continue..");
             d=sc.next();
            
            }while(!d.equals("n"));            
            
    }
    
    
    
}
